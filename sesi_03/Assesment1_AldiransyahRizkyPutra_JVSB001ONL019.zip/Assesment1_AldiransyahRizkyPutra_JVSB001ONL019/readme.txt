Nama			          : Aldiransyah Rizky Putra
Kode Peserta	          : JVSB001ONL019
Link GitHub			    : 
Panduan Penggunaan Aplikasi : 

1. LuasLingkaran.java
   - Program ini dibuat untuk menghitung luas lingkaran.
   - Pada program ini, dilakukan deklarasi class Scanner untuk memberikan input sesuai yang diinginkan serta 
     deklarasi variabel Luas, PI , dan r.
   - Lalu terdapat deskripsi untuk melakukan penginputan nilai r dengan Scanner
   - Angka masukan dari scanner yaitu nilai r, akan di proses ke dalam perhitungan luas lingkaran yang tersimpan
     di dalam variabel luas.
   - Sistem akan mencetak hasil dari perhitungan luas lingkaran tersebut.

2. Aritmatika.java
    - Program ini dibuat untuk menjalankan operasi aritmatika diantara 3 Angka
    - Pada program ini dilakukan deklarasi variabel a = 12, b = 8, dan c = 5
    - Lalu terdapat proses perhitungan diantaranya yaitu:
         a + b - c;
         a * b / c;
         a + b * c;        
         a + b / c;
        (a + b) * c;
        (a - b) * c; 
    - Keenam operasi tersebut tersimpan di dalam variabel hasil1 sampai dengan hasil6.
    - Lalu sistem akan mencetak hasil1 sampai dengan hasil6 sesuai dengan operasi aritmatika di setiap prosesnya.
    Soal
     a. Lakukan analisa baris kode apa saja yang tidak berjalan jika hasil yang diingkan: 
        15
        19
        52
        13
        100
        20 
        Jawaban : Semua baris kode berjalan dan kode tersebut sudah sesuai dengan hasil yang diharapkan
     b. Perbaiki Script Code, lalu kumpulkan perbaikan script code.
        Jawaban : Tidak ada yang perlu diperbaiki, karena source code sudah sesuai dengan yang diharapkan.

3. IncrementDecrement.java
    - Program ini dibuat untuk menentukan operator yang tepat untuk menjadi prefix maupun postfix
    - Dilakukan inisialisasi variabel a = 0, b = 0, c = 9, dan d = 9 
    - IncrementDecrement dilakukan kepada 4 variabel tersebut.
    - a++ = variabel dicetak dahulu, kemudian ditambah 1
    - ++a = variabel ditambah 1, kemudian dicetak
    - a-- = variabel dicetak dahulu, kemudian dikurang 1
    - --a = variabel dikurang 1, kemudian dicetak
    - Pada program ini penggunaan increment decrement disesuaikan dengan hasil yang sudah ditentukan

4. PerbandinganTrueFalse.java
    - Program ini dibuat untuk menentukan nilai True dan False dengan memanfaatkan operator pembanding.
    - Dilakukan inisialisasi variabel a = 10, b = 8, c = 12, dan d = 5
    - Terdapat 10 tes diantaranya: 
       a. Tes ke 1 = true (a > d -> bernilai true karena 10 > 5) 
       b. Tes ke 2 = true (b < c -> bernilai true karena 8 < 12)
       c. Tes ke 3 = true (c >= b -> bernilai true karena 12 > 8)
       d. tTs ke 4 = true (b <= a -> bernilai true karena 8 < 10)
       e. Tes ke 5 = true (c % d == a % b -> bernilai true karena 2 == 2)
       f. Tes ke 6 = true (a != b -> bernilai true karena 10 != 8)
       g. Tes ke 7 = false (b > c -> bernilai false karena 8 < 12)
       h. Tes ke 8 = false ( c <= d -> bernilai false karena 12 <= 5)
       i. Tes ke 9 = false (a == c -> bernilai false karena 10 == 12 )
       j. Tes ke 10 = false (c % d != a % b -> bernilai false karena 2 != 2)

5. Penjumlahan XY.java
    - Program ini dibuat untuk menjumlahkan dua variabel X dan Y kemudian dilakukan evaluasi.
    - Melakukan deklarasi variabel x1, x2, y1, y2
    - Pada program ini, dilakukan deklarasi class Scanner untuk memberikan input sesuai yang diinginkan untuk mengisi
      nilai pada variabell y1 dan y2.
    - Selanjutnya dibuat proses perhitungan nilai X1 dan X2 yang didalamnya terdapat perhitungan variabel y1 dan y2
    - Setelah mendapatkan nilai X1 dan X2, maka dilakukan evaluasi sebagai berikut:
      a. X1 besar sama dengan X2 ===> true
      b  X2 besar sama dengan X1 ===> false
      c. X1 mod 4 == ++X2 mod 5 ===> ture
          
   